import React, { useState, useEffect } from 'react';
import { 
  StyleSheet, Text, View, TextInput, TouchableOpacity, 
  FlatList, ScrollView, Alert, SafeAreaView, ActivityIndicator,
  Dimensions
} from 'react-native';
import { createClient } from '@supabase/supabase-js';

// Supabase configuration
const SUPABASE_URL = 'https://rxwllokulbjrkbrcnikf.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_TosgUWCBgC5bvX171JYGEw_8Q7IP9Ce';
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

interface Table {
  id: number;
  name: string;
  status: 'Available' | 'Ordered' | 'Cooking' | 'Serving' | 'Billing' | 'Reserved' | 'Cleaning';
  customer_name?: string;
  capacity: number;
}

interface WaiterRequest {
  id: string;
  table_id: string;
  request_type: 'Water' | 'Cutlery' | 'Tissue' | 'Call Waiter' | 'Request Bill';
  status: 'Pending' | 'Completed';
  created_at: string;
}

interface MenuItem {
  id: string;
  name: string;
  price: number;
  category: string;
  is_veg: boolean;
}

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [empid, setEmpid] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [waiterName, setWaiterName] = useState('');
  
  // Navigation State
  const [activeTab, setActiveTab] = useState<'tables' | 'alerts' | 'order'>('tables');
  
  // Data States
  const [tables, setTables] = useState<Table[]>([]);
  const [requests, setRequests] = useState<WaiterRequest[]>([]);
  const [menu, setMenu] = useState<MenuItem[]>([]);
  
  // New Order State
  const [selectedTable, setSelectedTable] = useState<number | null>(null);
  const [cart, setCart] = useState<Record<string, { item: MenuItem; qty: number }>>({});

  useEffect(() => {
    if (!isLoggedIn) return;
    
    // Fetch tables, requests, and menu
    fetchData();

    // Set polling interval for live updates
    const interval = setInterval(() => {
      fetchData();
    }, 4000);

    return () => clearInterval(interval);
  }, [isLoggedIn]);

  const fetchData = async () => {
    try {
      // 1. Fetch tables
      const { data: tableData } = await supabase
        .from('tables')
        .select('*')
        .order('id');
      if (tableData) setTables(tableData);

      // 2. Fetch active requests
      const { data: reqData } = await supabase
        .from('waiter_requests')
        .select('*')
        .eq('status', 'Pending')
        .order('created_at', { ascending: false });
      if (reqData) setRequests(reqData);

      // 3. Fetch menu
      const { data: menuData } = await supabase
        .from('menu_items')
        .select('*')
        .order('name');
      if (menuData) setMenu(menuData);
    } catch (e) {
      console.error('Error fetching mobile data:', e);
    }
  };

  const handleLogin = async () => {
    if (!empid.trim() || !password.trim()) {
      Alert.alert('Error', 'Please fill in employee ID and password');
      return;
    }

    setLoading(true);

    try {
      const { data, error } = await supabase
        .from('staff')
        .select('*')
        .eq('empid', empid.trim())
        .eq('password', password.trim())
        .single();

      if (error || !data) {
        Alert.alert('Auth Failed', 'Invalid employee credentials');
      } else if (data.role !== 'Waiter' && data.role !== 'Manager') {
        Alert.alert('Access Denied', 'Only waiters and managers can log in here.');
      } else {
        setWaiterName(data.name);
        setIsLoggedIn(true);
      }
    } catch (err) {
      Alert.alert('Error', 'Failed to authenticate');
    } finally {
      setLoading(false);
    }
  };

  const handleCompleteRequest = async (id: string) => {
    try {
      const { error } = await supabase
        .from('waiter_requests')
        .update({ status: 'Completed' })
        .eq('id', id);

      if (error) {
        Alert.alert('Error', 'Failed to update request');
      } else {
        setRequests(prev => prev.filter(r => r.id !== id));
      }
    } catch (e) {
      Alert.alert('Error', 'Unexpected error');
    }
  };

  const handleUpdateTableStatus = async (tableId: number, status: Table['status']) => {
    try {
      await supabase
        .from('tables')
        .update({ status })
        .eq('id', tableId);
      
      fetchData();
    } catch (e) {
      Alert.alert('Error', 'Failed to update table');
    }
  };

  const addToCart = (item: MenuItem) => {
    setCart(prev => {
      const existing = prev[item.id];
      return {
        ...prev,
        [item.id]: {
          item,
          qty: existing ? existing.qty + 1 : 1
        }
      };
    });
  };

  const removeFromCart = (itemId: string) => {
    setCart(prev => {
      const existing = prev[itemId];
      if (!existing) return prev;
      const updated = { ...prev };
      if (existing.qty <= 1) {
        delete updated[itemId];
      } else {
        updated[itemId] = { ...existing, qty: existing.qty - 1 };
      }
      return updated;
    });
  };

  const handlePlaceOrder = async () => {
    if (!selectedTable) {
      Alert.alert('Error', 'Please select a table number');
      return;
    }
    const cartItems = Object.values(cart);
    if (cartItems.length === 0) {
      Alert.alert('Error', 'Order cart is empty');
      return;
    }

    setLoading(true);

    try {
      const subtotal = cartItems.reduce((acc, c) => acc + (c.item.price * c.qty), 0);
      const gst = Math.round(subtotal * 0.05);
      const total = subtotal + gst;

      const orderItems = cartItems.map(c => ({
        menuItemId: c.item.id,
        name: c.item.name,
        price: c.item.price,
        quantity: c.qty,
        instructions: [],
        customNotes: ''
      }));

      const newOrder = {
        id: `ord_${Math.floor(1000 + Math.random() * 9000)}`,
        table_id: selectedTable.toString(),
        items: orderItems,
        subtotal,
        gst,
        discount: 0,
        tip: 0,
        total,
        status: 'Confirmed',
        payment_status: 'Pending'
      };

      const { error } = await supabase
        .from('orders')
        .insert(newOrder);

      if (error) {
        Alert.alert('Error', 'Failed to place order in database');
      } else {
        // Also update table status
        await supabase
          .from('tables')
          .update({ status: 'Ordered' })
          .eq('id', selectedTable);

        Alert.alert('Success', `Placed Order #${newOrder.id} successfully!`);
        setCart({});
        setSelectedTable(null);
        setActiveTab('tables');
      }
    } catch (err) {
      Alert.alert('Error', 'Failed to place order');
    } finally {
      setLoading(false);
    }
  };

  if (!isLoggedIn) {
    return (
      <SafeAreaView style={styles.loginContainer}>
        <View style={styles.loginCard}>
          <Text style={styles.title}>DineSmart Waiter</Text>
          <Text style={styles.subtitle}>Mobile Service Pad</Text>
          
          <TextInput
            style={styles.input}
            placeholder="Employee ID (empid)"
            value={empid}
            onChangeText={setEmpid}
            autoCapitalize="none"
          />
          <TextInput
            style={styles.input}
            placeholder="Password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />

          <TouchableOpacity style={styles.button} onPress={handleLogin} disabled={loading}>
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.buttonText}>Log In</Text>
            )}
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.waiterName}>Hello, {waiterName}</Text>
          <Text style={styles.headerDesc}>Waiter Terminal</Text>
        </View>
        <TouchableOpacity style={styles.logoutBtn} onPress={() => setIsLoggedIn(false)}>
          <Text style={styles.logoutText}>Logout</Text>
        </TouchableOpacity>
      </View>

      {/* Tabs */}
      <View style={styles.tabContainer}>
        <TouchableOpacity 
          style={[styles.tabButton, activeTab === 'tables' && styles.activeTab]} 
          onPress={() => setActiveTab('tables')}
        >
          <Text style={[styles.tabText, activeTab === 'tables' && styles.activeTabText]}>Tables</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.tabButton, activeTab === 'alerts' && styles.activeTab]} 
          onPress={() => setActiveTab('alerts')}
        >
          <Text style={[styles.tabText, activeTab === 'alerts' && styles.activeTabText]}>
            Alerts ({requests.length})
          </Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.tabButton, activeTab === 'order' && styles.activeTab]} 
          onPress={() => setActiveTab('order')}
        >
          <Text style={[styles.tabText, activeTab === 'order' && styles.activeTabText]}>Order Pad</Text>
        </TouchableOpacity>
      </View>

      {/* Viewports */}
      <View style={styles.mainView}>
        {activeTab === 'tables' && (
          <ScrollView>
            <View style={styles.tablesGrid}>
              {tables.map(t => (
                <View key={t.id} style={styles.tableCard}>
                  <Text style={styles.tableName}>{t.name}</Text>
                  <Text style={styles.tableCap}>Capacity: {t.capacity}</Text>
                  <Text style={[styles.tableStatus, { 
                    color: t.status === 'Available' ? '#22c55e' : 
                           t.status === 'Reserved' ? '#ef4444' : '#f97316' 
                  }]}>
                    {t.status}
                  </Text>
                  
                  <View style={styles.actionRow}>
                    <TouchableOpacity 
                      style={styles.actionBtn}
                      onPress={() => handleUpdateTableStatus(t.id, 'Serving')}
                    >
                      <Text style={styles.actionBtnText}>Serve</Text>
                    </TouchableOpacity>
                    <TouchableOpacity 
                      style={[styles.actionBtn, { backgroundColor: '#e2e8f0' }]}
                      onPress={() => handleUpdateTableStatus(t.id, 'Available')}
                    >
                      <Text style={[styles.actionBtnText, { color: '#475569' }]}>Clear</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              ))}
            </View>
          </ScrollView>
        )}

        {activeTab === 'alerts' && (
          <FlatList
            data={requests}
            keyExtractor={item => item.id}
            renderItem={({ item }) => (
              <View style={styles.alertCard}>
                <View>
                  <Text style={styles.alertTable}>Table {item.table_id}</Text>
                  <Text style={styles.alertType}>{item.request_type}</Text>
                </View>
                <TouchableOpacity 
                  style={styles.completeBtn} 
                  onPress={() => handleCompleteRequest(item.id)}
                >
                  <Text style={styles.completeText}>Complete</Text>
                </TouchableOpacity>
              </View>
            )}
            ListEmptyComponent={
              <Text style={styles.emptyText}>No pending table service requests.</Text>
            }
          />
        )}

        {activeTab === 'order' && (
          <View style={{ flex: 1 }}>
            <Text style={styles.sectionTitle}>Select Table</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tablePicker}>
              {tables.map(t => (
                <TouchableOpacity 
                  key={t.id}
                  style={[styles.pickerBtn, selectedTable === t.id && styles.activePicker]}
                  onPress={() => setSelectedTable(t.id)}
                >
                  <Text style={[styles.pickerText, selectedTable === t.id && styles.activePickerText]}>
                    T{t.id}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>

            <Text style={styles.sectionTitle}>Menu Items</Text>
            <FlatList
              data={menu}
              keyExtractor={item => item.id}
              style={{ flex: 1 }}
              renderItem={({ item }) => {
                const qty = cart[item.id]?.qty || 0;
                return (
                  <View style={styles.menuRow}>
                    <View>
                      <Text style={styles.menuName}>{item.name}</Text>
                      <Text style={styles.menuPrice}>₹{item.price}</Text>
                    </View>
                    <View style={styles.qtyContainer}>
                      <TouchableOpacity style={styles.qtyBtn} onPress={() => removeFromCart(item.id)}>
                        <Text style={styles.qtyText}>-</Text>
                      </TouchableOpacity>
                      <Text style={styles.qtyVal}>{qty}</Text>
                      <TouchableOpacity style={styles.qtyBtn} onPress={() => addToCart(item)}>
                        <Text style={styles.qtyText}>+</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                );
              }}
            />

            <TouchableOpacity style={styles.orderSubmitBtn} onPress={handlePlaceOrder}>
              <Text style={styles.submitBtnText}>Submit Order to Kitchen</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  loginContainer: {
    flex: 1,
    backgroundColor: '#FFF8F0',
    alignItems: 'center',
    justifyContent: 'center',
  },
  loginCard: {
    width: '85%',
    backgroundColor: '#fff',
    borderRadius: 24,
    padding: 24,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
  },
  title: {
    fontSize: 22,
    fontWeight: '900',
    textAlign: 'center',
    color: '#2D2D2D',
  },
  subtitle: {
    fontSize: 12,
    textAlign: 'center',
    color: '#ff7a00',
    fontWeight: '700',
    marginBottom: 24,
  },
  input: {
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 14,
    padding: 12,
    fontSize: 13,
    marginBottom: 14,
  },
  button: {
    backgroundColor: '#ff7a00',
    borderRadius: 14,
    padding: 14,
    alignItems: 'center',
    marginTop: 8,
  },
  buttonText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 14,
  },
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 16,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  waiterName: {
    fontSize: 16,
    fontWeight: '950',
    color: '#2D2D2D',
  },
  headerDesc: {
    fontSize: 10,
    color: '#94a3b8',
    fontWeight: '700',
  },
  logoutBtn: {
    alignSelf: 'center',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 8,
    backgroundColor: '#fef2f2',
  },
  logoutText: {
    color: '#ef4444',
    fontSize: 11,
    fontWeight: '700',
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    paddingHorizontal: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  tabButton: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
  },
  activeTab: {
    borderBottomWidth: 3,
    borderBottomColor: '#ff7a00',
  },
  tabText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#94a3b8',
  },
  activeTabText: {
    color: '#ff7a00',
  },
  mainView: {
    flex: 1,
    padding: 16,
  },
  tablesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  tableCard: {
    width: '48%',
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 12,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  tableName: {
    fontSize: 13,
    fontWeight: '900',
  },
  tableCap: {
    fontSize: 9,
    color: '#94a3b8',
    fontWeight: '700',
    marginTop: 2,
  },
  tableStatus: {
    fontSize: 10,
    fontWeight: '800',
    marginTop: 6,
  },
  actionRow: {
    flexDirection: 'row',
    gap: 6,
    marginTop: 10,
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
    paddingTop: 8,
  },
  actionBtn: {
    flex: 1,
    backgroundColor: '#ff7a00',
    borderRadius: 8,
    paddingVertical: 6,
    alignItems: 'center',
  },
  actionBtnText: {
    color: '#fff',
    fontSize: 9,
    fontWeight: '700',
  },
  alertCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 14,
    marginBottom: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  alertTable: {
    fontSize: 13,
    fontWeight: '900',
  },
  alertType: {
    fontSize: 10,
    color: '#ff7a00',
    fontWeight: '700',
    marginTop: 2,
  },
  completeBtn: {
    backgroundColor: '#22c55e',
    borderRadius: 10,
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  completeText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: '700',
  },
  emptyText: {
    textAlign: 'center',
    color: '#94a3b8',
    fontSize: 12,
    marginTop: 40,
    fontWeight: '600',
  },
  sectionTitle: {
    fontSize: 12,
    fontWeight: '900',
    color: '#64748b',
    marginBottom: 10,
    textTransform: 'uppercase',
  },
  tablePicker: {
    flexDirection: 'row',
    marginBottom: 16,
    paddingBottom: 4,
  },
  pickerBtn: {
    width: 44,
    height: 44,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#cbd5e1',
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 8,
  },
  activePicker: {
    backgroundColor: '#ff7a00',
    borderColor: '#ff7a00',
  },
  pickerText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#475569',
  },
  activePickerText: {
    color: '#fff',
  },
  menuRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 14,
    marginBottom: 8,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  menuName: {
    fontSize: 13,
    fontWeight: '800',
  },
  menuPrice: {
    fontSize: 11,
    color: '#64748b',
    fontWeight: '700',
  },
  qtyContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  qtyBtn: {
    width: 28,
    height: 28,
    borderRadius: 8,
    backgroundColor: '#f1f5f9',
    alignItems: 'center',
    justifyContent: 'center',
  },
  qtyText: {
    fontSize: 16,
    fontWeight: '700',
  },
  qtyVal: {
    width: 16,
    textAlign: 'center',
    fontSize: 12,
    fontWeight: '800',
  },
  orderSubmitBtn: {
    backgroundColor: '#ff7a00',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    marginTop: 10,
  },
  submitBtnText: {
    color: '#fff',
    fontWeight: '800',
    fontSize: 13,
  }
});
